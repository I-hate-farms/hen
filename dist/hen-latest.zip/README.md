This is a set of CMake modules: Translations, GSettings, and Vala modules.

For all the Vala related modules see README.Vala.rst: 
    - ParseArguments.cmake
    - ValaPrecompile.cmake
    - ValaVersion.cmake
    - FindVala.cmake

